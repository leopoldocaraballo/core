package com.vengalsas.core.conciliation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConciliationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
