package com.vengalsas.core.conciliation.infrastructure.adapter;

import java.io.InputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Component;

import com.vengalsas.core.conciliation.domain.model.SourceSystem;
import com.vengalsas.core.conciliation.domain.model.Transaction;
import com.vengalsas.core.conciliation.domain.model.TransactionType;

@Component
public class BancolombiaExcelReader {

  private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

  public List<Transaction> read(InputStream inputStream) throws Exception {
    List<Transaction> transactions = new ArrayList<>();

    try (Workbook workbook = WorkbookFactory.create(inputStream)) {
      Sheet sheet = workbook.getSheetAt(0);
      int totalRows = sheet.getPhysicalNumberOfRows();
      System.out.println("🧾 Bancolombia Excel - Total rows: " + totalRows);

      for (Row row : sheet) {
        if (row == null || row.getPhysicalNumberOfCells() < 9)
          continue;

        try {
          String dateStr = getCellValueAsString(row.getCell(0));
          String reference = getCellValueAsString(row.getCell(2));
          String description = getCellValueAsString(row.getCell(6));
          String debitStr = getCellValueAsString(row.getCell(7)).replace(",", "").replace(".", "");
          String creditStr = getCellValueAsString(row.getCell(8)).replace(",", "").replace(".", "");

          if (dateStr.isBlank() || description.isBlank())
            continue;

          LocalDate date = LocalDate.parse(dateStr.trim(), DATE_FORMAT);
          BigDecimal amount;
          TransactionType type;

          if (!debitStr.isEmpty() && !debitStr.equals("0")) {
            amount = new BigDecimal(debitStr);
            type = TransactionType.DEBIT;
          } else if (!creditStr.isEmpty() && !creditStr.equals("0")) {
            amount = new BigDecimal(creditStr);
            type = TransactionType.CREDIT;
          } else {
            continue;
          }

          Transaction transaction = Transaction.builder()
              .date(date)
              .description(description.trim())
              .amount(amount)
              .transactionType(type)
              .source(SourceSystem.BANCOLUMBIA)
              .reference(reference != null ? reference.trim() : "")
              .build();

          transactions.add(transaction);
          System.out.println("✅ Bancolombia parsed: " + transaction);

        } catch (Exception e) {
          System.err.println("⚠️ Skipping Bancolombia row [" + row.getRowNum() + "]: " + e.getMessage());
        }
      }
    }

    System.out.println("✔️ Total Bancolombia transactions parsed: " + transactions.size());
    return transactions;
  }

  private String getCellValueAsString(Cell cell) {
    if (cell == null)
      return "";
    return switch (cell.getCellType()) {
      case STRING -> cell.getStringCellValue();
      case NUMERIC -> DateUtil.isCellDateFormatted(cell)
          ? DATE_FORMAT.format(cell.getLocalDateTimeCellValue().toLocalDate())
          : String.valueOf((long) cell.getNumericCellValue());
      case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
      case FORMULA -> cell.getCellFormula();
      default -> "";
    };
  }
}
