package com.vengalsas.core.conciliation.infrastructure.adapter;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.vengalsas.core.conciliation.domain.model.SourceSystem;
import com.vengalsas.core.conciliation.domain.model.Transaction;
import com.vengalsas.core.conciliation.domain.model.TransactionType;

@Component
public class LinixCsvReader {

  private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

  public List<Transaction> read(InputStream inputStream) throws Exception {
    List<Transaction> transactions = new ArrayList<>();
    List<String> headers = new ArrayList<>();
    List<String[]> validRows = new ArrayList<>();

    try (BufferedReader reader = new BufferedReader(
        new InputStreamReader(inputStream, StandardCharsets.ISO_8859_1))) {

      String line;
      boolean headerDetected = false;

      while ((line = reader.readLine()) != null) {
        String[] columns = line.split("\t");

        if (!headerDetected && Arrays.asList(columns).contains("Fecha")) {
          headers.addAll(Arrays.asList(columns));
          headerDetected = true;
          continue;
        }

        if (headerDetected) {
          validRows.add(columns);
        }
      }

      if (!headerDetected) {
        throw new IllegalArgumentException("❌ Invalid accounting file: expected headers not found.");
      }

      int idxFecha = headers.indexOf("Fecha");
      int idxDescripcion = headers.indexOf("Descripción");
      int idxDebito = headers.indexOf("Débito");
      int idxCredito = headers.indexOf("Crédito");
      int idxNumero = headers.indexOf("Número");

      for (String[] columns : validRows) {
        if (columns.length <= Math.max(Math.max(idxFecha, idxDescripcion), Math.max(idxDebito, idxCredito))) {
          continue;
        }

        try {
          String dateStr = columns[idxFecha].trim();
          String description = columns[idxDescripcion].trim();
          String debitStr = columns[idxDebito].replace(".", "").replace(",", ".").trim();
          String creditStr = columns[idxCredito].replace(".", "").replace(",", ".").trim();
          String reference = idxNumero < columns.length ? columns[idxNumero].trim() : "";

          if (dateStr.isEmpty() || description.isEmpty())
            continue;

          LocalDate date = LocalDate.parse(dateStr, DATE_FORMAT);
          BigDecimal amount;
          TransactionType type;

          if (!debitStr.isEmpty() && !debitStr.equals("0.00")) {
            amount = new BigDecimal(debitStr);
            type = TransactionType.DEBIT;
          } else if (!creditStr.isEmpty() && !creditStr.equals("0.00")) {
            amount = new BigDecimal(creditStr);
            type = TransactionType.CREDIT;
          } else {
            continue;
          }

          Transaction transaction = Transaction.builder()
              .date(date)
              .description(description)
              .amount(amount)
              .transactionType(type)
              .source(SourceSystem.LINIX)
              .reference(reference)
              .build();

          transactions.add(transaction);
          System.out.println("✅ Linix parsed: " + transaction);

        } catch (Exception e) {
          System.err.println(e + "⚠️ Error processing Linix row: " + Arrays.toString(columns));

        }
      }
    }

    System.out.println("✔️ Total Linix transactions parsed: " + transactions.size());
    return transactions;
  }
}
