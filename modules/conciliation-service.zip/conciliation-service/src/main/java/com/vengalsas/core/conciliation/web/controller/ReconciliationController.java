package com.vengalsas.core.conciliation.web.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.vengalsas.core.conciliation.application.service.ReconciliationService;
import com.vengalsas.core.conciliation.domain.model.SourceSystem;
import com.vengalsas.core.conciliation.domain.model.Transaction;
import com.vengalsas.core.conciliation.web.dto.ConciliationResultDTO;
import com.vengalsas.core.conciliation.web.dto.NormalizedTransactionResponseDTO;
import com.vengalsas.core.conciliation.web.dto.ReconciliationRequestDTO;
import com.vengalsas.core.conciliation.web.dto.TransactionResponseDTO;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/conciliation")
@RequiredArgsConstructor
public class ReconciliationController {

  private final ReconciliationService reconciliationService;

  @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public NormalizedTransactionResponseDTO uploadFiles(
      @RequestPart("bankFile") MultipartFile bankFile,
      @RequestPart("accountingFile") MultipartFile accountingFile) throws Exception {

    List<Transaction> transactions = reconciliationService.readAndNormalize(bankFile, accountingFile);

    List<TransactionResponseDTO> linix = transactions.stream()
        .filter(tx -> tx.getSource() == SourceSystem.LINIX)
        .map(this::toDto)
        .collect(Collectors.toList());

    List<TransactionResponseDTO> bancolombia = transactions.stream()
        .filter(tx -> tx.getSource() == SourceSystem.BANCOLUMBIA)
        .map(this::toDto)
        .collect(Collectors.toList());

    return NormalizedTransactionResponseDTO.builder()
        .linixTransactions(linix)
        .bancolombiaTransactions(bancolombia)
        .build();
  }

  @PostMapping(value = "/reconcile", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public List<ConciliationResultDTO> reconcile(@RequestBody ReconciliationRequestDTO request) {
    return reconciliationService.reconcileTransactions(request);
  }

  private TransactionResponseDTO toDto(Transaction tx) {
    return TransactionResponseDTO.builder()
        .date(tx.getDate())
        .description(tx.getDescription())
        .amount(tx.getAmount())
        .transactionType(tx.getTransactionType())
        .source(tx.getSource())
        .reference(tx.getReference())
        .build();
  }
}
