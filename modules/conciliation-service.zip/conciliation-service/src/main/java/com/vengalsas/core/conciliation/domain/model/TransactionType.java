package com.vengalsas.core.conciliation.domain.model;

public enum TransactionType {
  DEBIT,
  CREDIT
}
