package com.vengalsas.core.conciliation.web.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.vengalsas.core.conciliation.domain.model.SourceSystem;
import com.vengalsas.core.conciliation.domain.model.TransactionType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionResponseDTO {
  private LocalDate date;
  private String description;
  private BigDecimal amount;
  private TransactionType transactionType;
  private SourceSystem source;
  private String reference;
}
