package com.vengalsas.core.conciliation.application.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.vengalsas.core.conciliation.domain.model.Transaction;
import com.vengalsas.core.conciliation.infrastructure.adapter.BancolombiaExcelReader;
import com.vengalsas.core.conciliation.infrastructure.adapter.LinixCsvReader;
import com.vengalsas.core.conciliation.web.dto.ConciliationResultDTO;
import com.vengalsas.core.conciliation.web.dto.ReconciliationRequestDTO;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ReconciliationService {

  private final BancolombiaExcelReader bancolombiaExcelReader;
  private final LinixCsvReader linixCsvReader;

  public List<Transaction> readAndNormalize(MultipartFile bankFile, MultipartFile accountingFile) throws Exception {
    List<Transaction> result = new ArrayList<>();
    result.addAll(bancolombiaExcelReader.read(bankFile.getInputStream()));
    result.addAll(linixCsvReader.read(accountingFile.getInputStream()));
    return result;
  }

  public List<ConciliationResultDTO> reconcileTransactions(ReconciliationRequestDTO request) {
    List<Transaction> linix = request.getLinixTransactions();
    List<Transaction> banco = request.getBancolombiaTransactions();
    List<ConciliationResultDTO> results = new ArrayList<>();

    for (Transaction linixTx : linix) {
      boolean matched = false;
      for (Transaction bankTx : banco) {
        if (linixTx.getAmount().compareTo(bankTx.getAmount()) == 0 &&
            linixTx.getDate().isEqual(bankTx.getDate())) {

          results.add(ConciliationResultDTO.builder()
              .linixTransaction(linixTx)
              .bancolombiaTransaction(bankTx)
              .matched(true)
              .build());
          matched = true;
          break;
        }
      }

      if (!matched) {
        results.add(ConciliationResultDTO.builder()
            .linixTransaction(linixTx)
            .bancolombiaTransaction(null)
            .matched(false)
            .build());
      }
    }

    return results;
  }
}
